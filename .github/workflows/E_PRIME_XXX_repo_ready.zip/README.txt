E PRIME XXX — APK READY WEBVIEW PROJECT

Contents:
- app/src/main/assets/index.html — E PRIME XXX ESP functional index
- app/src/main/res/drawable-nodpi/e_prime_xxx_poster.png — project artwork

Important:
This package contains the UI/demo ESP interface from the supplied HTML. It does not implement real-player tracking, aim assistance, or game manipulation.

Build in Android Studio by creating a WebView Activity that loads file:///android_asset/index.html and using the poster as app branding.
