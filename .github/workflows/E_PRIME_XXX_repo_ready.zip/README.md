# E PRIME XXX — GitHub APK Build

This repository is ready for GitHub Actions. Push the contents of this folder to a GitHub repository with the default branch named `main`.

## Build APK
1. Open the repository on GitHub.
2. Go to **Actions**.
3. Select **Build E PRIME XXX APK**.
4. Tap **Run workflow** (or push to `main`).
5. When the workflow finishes, open the run and download the **E-PRIME-XXX-debug-apk** artifact.

The app is a WebView wrapper around the supplied E PRIME XXX ESP interface and includes the generated project artwork. The supplied HTML contains a demonstration ESP UI; this package does not implement real-player tracking, aim assistance, or game manipulation.
